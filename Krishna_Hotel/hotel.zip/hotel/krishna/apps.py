from django.apps import AppConfig


class KrishnaConfig(AppConfig):
    name = 'krishna'
